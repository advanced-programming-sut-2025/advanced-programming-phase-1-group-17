package controllers;

public class LoginMenuController {
    public Result loginUser(){}
    public Result forgotPassword(){}
}
