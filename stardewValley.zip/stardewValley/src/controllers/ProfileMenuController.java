package controllers;

import models.Result;

public class ProfileMenuController {

    public Result showUserInfo(){}

    public Result changeUserName(){}

    public Result changeNickName(){}

    public Result changeEmail(){}

    public Result changePassword(){}

}
