package controllers;

import models.Result;

public class GameMenuController {
    public Result newGame(String username1, String username2, String username3) {

    }

    public Result gameMap(String mapNumber) {

    }


    public Result loadGame() {

    }


    public Result exitGame() {

    }

    public Result removeCurrentGame() {
    }

    public Result nextTurn() {
    }

    public Result getTime() {
    }

    public Result getDate() {
    }

    public Result getDateTime() {
    }

    public Result getDayOfTheWeek() {
    }

    public Result getSeason() {
    }

    public Result changeTime(String input) {
    }

    public Result changeDate(String input) {
    }

    public Result getWeather() {
    }

    public Result WeatherForeCast(String input) {
    }

    public Result changeWeather(String input) {
    }

    public Result buildGreenHouse() {
    }

    public Result walk(int x, int y) {
    }

    public Result printMap(int x, int y, int size {
    }

    public Result helpReadingMap() {
    }

    public Result energyShow() {
    }

    public Result energySet(String value) {
    }

    public Result energyUnlimited() {
    }

    public Result inventoryShow() {
    }

    public Result inventoryTrash(String itemName, String number) {
    }

    public Result toolEquip(String toolName) {
    }

    public Result currentToolShow(String toolName) {
    }

    public Result toolsShow() {
    }

    public Result toolUpgrade(String toolName) {
    }

    public Result toolUse(String direction) {
    }

    public Result craftInfo(String name) {
    }

    public Result plantSeed(String seed, String direction) {
    }

    public Result showPlant(String x, String y) {
    }

    public Result fertilize(String fertilizer, String direction) {
    }

    public Result howMuchWater() {
    }

    public Result craftingShowRecipes() {
    }

    public Result craftingCraft(String itemName) {
    }

    public Result placeItem(String itemName, String direction) {
    }

    public Result addItem(String itemName, String number) {
    }

    public Result cookingPrepare(String recipeName) {
    }

    public Result eat(String foodName) {
    }

    public Result build(String name, String x, String y) {
    }

    public Result buyAnimal(String animal, String name) {
    }

    public Result pet(String name) {
    }

    public Result setFriendship(String animalName, String amount) {
    }

    public Result animals() {
    }

    public Result shepherdAnimal(String animalName, String x, String y) {
    }

    public Result feedHay(String animalName) {
    }

    public Result produce() {
    }

    public Result collectProduct(String name) {
    }

    public Result sellAnimal(String name) {
    }

    public Result fishing(String fishingPole) {
    }

    public Result artisianUse(String artisianName, String itemName) {
    }

    public Result artisianGet(String artisianName) {
    }

    public Result showAllProducts() {
    }

    public Result showAllAvailableProducts() {
    }

    public Result purchase(String productName, String count) {
    }

    public Result addDollars(String count) {
    }

    public Result sellProduct(String productName, String count) {
    }

    public Result friendship() {
    }

    public Result talk(String username, String massage) {
    }

    public Result talkHistory(String username) {
    }

    public Result gift(String username, String item, String amount) {
    }

    public Result giftList() {
    }

    public Result giftRate(String giftNumber, String rate) {
    }

    public Result giftHistory(String username) {
    }

    public Result hug(String username) {
    }

    public Result flower(String username) {
    }

    public Result askMarriage(String username, String marriage) {
    }

    public Result respond(String username) {
    }

    public Result startTrade() {
    }

    public Result trade(String username, String type, String amount, String price, String targetItem) {
    }

    public Result tradeResponse(String acceptance, String id) {
    }

    public Result tradeHistory() {}

    public Result tradeList() {
    }

    public Result meetNPC(String npcName) {
    }

    public Result giftNPC(String NPCName, String item) {
    }

    public Result friendshipNPCList() {
    }

    public Result questsList() {
    }

    public Result questFinish(String index) {
    }


}
