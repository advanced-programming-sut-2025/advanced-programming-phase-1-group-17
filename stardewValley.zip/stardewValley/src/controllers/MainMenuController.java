package controllers;

public class MainMenuController {
    public void changeMenu(){}
    public void logOut(){}
}
