package controllers;

import models.Result;

public class SignUpMenuController {
    public Result enterLoginMenu() {

    }


    public Result enterMainMenu() {

    }


    public void exit() {

    }

    public Result showCurrentMenu() {

    }

    public Result register(String username,
                           String password,
                           String passwordConfirm,
                           String nickname,
                           String email,
                           String gender) {

    }

}
