package models;

public class Foraging {
}
