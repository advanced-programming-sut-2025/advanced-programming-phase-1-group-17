package models;

public class Ability {
}
