package models;

public class Product {
    private int count;
    private double price;
}
