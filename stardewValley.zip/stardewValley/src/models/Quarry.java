package models;

public class Quarry {
}
