package models;

public class Recipe {
    private String name;
    private Food foodToBeCooked;
}
