package models;

public class Gift {
    private int giftNumber;
    private Product product;
}
