package models;

public class Ring {

}
