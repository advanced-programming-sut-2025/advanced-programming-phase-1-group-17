package models;

public class Stone {
}
