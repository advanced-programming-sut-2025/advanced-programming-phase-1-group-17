package models;

import java.util.ArrayList;

public class Talk {
    private boolean player1TalkFirst;
    private ArrayList<String> talkPlayer1 = new ArrayList<>();
    private ArrayList<String> talkPlayer2 = new ArrayList<>();

}
