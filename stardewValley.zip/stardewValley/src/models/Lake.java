package models;

public class Lake {
}
