package models;

import java.util.ArrayList;

public class Barn {
    private ArrayList<Animal> animals=new ArrayList<>();
    private ArrayList<Tile> tiles=new ArrayList<>();

}
