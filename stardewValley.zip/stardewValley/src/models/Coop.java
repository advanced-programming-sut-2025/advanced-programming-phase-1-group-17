package models;

import java.util.ArrayList;

public class Coop {
    private ArrayList<Animal> animals=new ArrayList<>();
    private ArrayList<Tile> tiles=new ArrayList<>();

}
