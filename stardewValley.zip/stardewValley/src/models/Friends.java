package models;

import java.util.ArrayList;
import java.util.HashMap;

public class Friends {
    private Player player;
    HashMap<Player,Talk> historyTalk=new HashMap<>();
    private int friendShipLevel;
    ArrayList<Product>giftHistory=new ArrayList<>();
    public void talk(){}

}
