package models;

public class Food {
    private String name;
    private int count;
}
