package models;

public class Tree {
    private int growthPeriod;
    private boolean isHitByLightning;
    public int age;
}
