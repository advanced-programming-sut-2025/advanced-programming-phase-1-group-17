package models.enums;

public enum ToolName {
    Pichaxe,
    Scythe,
    Hoe,
    Axe,
    WateringCan,
    FishingPole,
    MilkPail,
    Shear,
    TrashCan;
}
