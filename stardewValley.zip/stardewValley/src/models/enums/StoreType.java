package models.enums;

public enum StoreType {
}
