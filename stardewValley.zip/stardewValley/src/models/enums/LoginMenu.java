package models.enums;

public enum LoginMenu {
}
