package models.enums;

public enum ToolMaterial {
    Basic,
    Copper,
    Iron,
    Gold,
    Iridium;

}
