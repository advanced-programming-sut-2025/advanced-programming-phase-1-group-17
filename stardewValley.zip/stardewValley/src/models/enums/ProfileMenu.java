package models.enums;

public enum ProfileMenu {

    s("");

    String regex;

    ProfileMenu(String regex) {
        this.regex = regex;
    }

    public M
}
