package models.enums;

public enum AnimalType {
    Coop, Barn;
}
