package models.enums;

public enum DaysOfTheWeek {
}
