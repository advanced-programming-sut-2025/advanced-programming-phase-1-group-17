package models.enums;

public enum Foragings {
}
