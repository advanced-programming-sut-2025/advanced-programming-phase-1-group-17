package models.enums;

public enum SignUpMenu {
}
