package models.enums;

public enum VegetableType {

}
