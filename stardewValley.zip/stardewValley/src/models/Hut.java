package models;

public class Hut {
}
