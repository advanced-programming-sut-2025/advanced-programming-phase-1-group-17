package models;

public class Character {
    private int x;
    private int y;

}
