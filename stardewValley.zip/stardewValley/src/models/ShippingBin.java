package models;

import models.enums.ShippingBinType;

public class ShippingBin {
    private ShippingBinType type;

}
