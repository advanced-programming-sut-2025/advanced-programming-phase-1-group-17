package models.NPCS;

import models.NPC;

public class Robin extends NPC {
}
