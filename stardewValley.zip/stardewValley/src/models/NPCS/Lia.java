package models.NPCS;

import models.NPC;

public class Lia extends NPC {
}
