package models.NPCS;

import models.NPC;

public class Harvey extends NPC {
}
