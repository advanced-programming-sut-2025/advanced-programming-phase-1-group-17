package models.NPCS;

import models.NPC;

public class Sebastian extends NPC {
}
