package models;

public class Quest {
    private boolean isActive = false;
    public void giveReward(Player player){}

}
