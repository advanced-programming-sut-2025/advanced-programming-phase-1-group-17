package models;

import java.util.ArrayList;

public class BackPack {
    private ArrayList<Seed> seeds = new ArrayList<>();
    private ArrayList<Tool> tools = new ArrayList<>();
    private ArrayList<Product> products = new ArrayList<>();

}
