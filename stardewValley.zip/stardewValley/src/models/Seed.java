package models;

public class Seed {
    private String name;
    private boolean isMixed;
}
