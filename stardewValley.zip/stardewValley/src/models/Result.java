package models;

public class Result {

}
