package models;

import models.enums.ToolMaterial;
import models.enums.ToolName;

public class Tool {
    private ToolName name;
    private ToolMaterial material;

}
