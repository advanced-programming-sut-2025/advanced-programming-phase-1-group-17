package models;

public class AnimalProduct {
    private Animal animal;
    private String name;
    private int count;

}
