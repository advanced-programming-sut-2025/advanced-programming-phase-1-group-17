package views;

import java.util.Scanner;

public class ProfileMenu implements AppMenu {
    public void run(Scanner scanner) {}
}
