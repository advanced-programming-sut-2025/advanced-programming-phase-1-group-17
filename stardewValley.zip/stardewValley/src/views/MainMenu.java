package views;

import java.util.Scanner;

public class MainMenu implements AppMenu {
    public void run(Scanner scanner) {}
}
