package views;

import java.util.Scanner;

public class SignUpMenu implements AppMenu {
    public void run(Scanner scanner) {}
}
