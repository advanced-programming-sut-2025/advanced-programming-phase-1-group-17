package views;

import java.util.Scanner;

public class LoginMenu implements AppMenu {
    public void run(Scanner scanner) {}
}
