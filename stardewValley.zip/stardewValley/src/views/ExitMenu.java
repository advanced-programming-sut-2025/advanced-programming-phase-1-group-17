package views;

import models.App;

import java.util.Scanner;

public class ExitMenu implements AppMenu {
    public void run(Scanner scanner) {}
}
