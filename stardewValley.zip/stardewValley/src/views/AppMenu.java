package views;

import java.util.Scanner;

public interface AppMenu {
    void run(Scanner scanner);

}

